# 15/10/24

print("Enter X-Coordinate")
x1 = int(input("x1: "))
x2 = int(input("x2: "))

print('\n')

print("Enter Y-Coordinate")
y1 = int(input("y1: "))
y2 = int(input("y2: "))


Distance = ((x2-x1)**2+(y2-y1)**2)**0.5

print('\n')

print("Distance between two points is: ",round(Distance,3))

