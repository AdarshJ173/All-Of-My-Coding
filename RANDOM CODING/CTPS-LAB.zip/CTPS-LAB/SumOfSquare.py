n = 1
sum = 0
x = int(input("Enter a number: "))

for i in range(x):
    sum += n**2
    n += 1
print(sum)