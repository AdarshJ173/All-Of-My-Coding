num = int(input())

if(num == 0 ):
    print("0")
elif(num == 1):
    print("odd")
else:
    if(num%2 == 0):
        print("even")
    else:
        print("ood")

# name = "AAJ"
for i in range(20):
    print()