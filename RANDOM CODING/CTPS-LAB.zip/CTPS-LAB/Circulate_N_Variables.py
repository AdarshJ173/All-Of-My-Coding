# 15/10/24

O_list = [4,6,12,16,20,24]
print("Old List: " ,O_list)

list1 = O_list[:3]
list2 = O_list[3:]

N_List = list2+list1

print("New List: ",N_List)