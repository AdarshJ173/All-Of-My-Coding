//! MOVE ZEROS
// https://leetcode.com/problems/move-zeroes/submissions/1272064725/

