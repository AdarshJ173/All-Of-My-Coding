#include<iostream>
using namespace std;

int main(){
    int arr[] = {11,12,13,14,15};
    cout<<*(arr)<<" "<<*(arr+3);

    return 0;

    /// phir se sahi jawab
}