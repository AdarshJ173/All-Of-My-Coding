#include<iostream>
using namespace std;

int main(){
    int arr[5]; // 4*5 = 20
    int *ptr; // 8 or 4
    cout<<sizeof(arr)<<" "<<sizeof(ptr)<<endl;

    return 0;
}