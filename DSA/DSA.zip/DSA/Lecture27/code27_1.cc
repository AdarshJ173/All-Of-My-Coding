/// MCQ
#include<iostream>
using namespace std;

int main(){

    int fst = 8;
    int sec = 18;

    int *ptr = &sec;
    *ptr = 9;

    cout<<fst<<" "<<sec<<endl; 

    //* EK DAM SHAI ANS DIYA BC...
}