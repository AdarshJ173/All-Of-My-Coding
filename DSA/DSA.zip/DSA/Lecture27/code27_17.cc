#include<iostream>
using namespace std;

int main(){
    char str[] = "adarsh";
    char *p = str;
    cout<<str[0]<<" "<<p[0] <<endl;

    return 0;

    /// simple bola tha , yehi hoga 
}