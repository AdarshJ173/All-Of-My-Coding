#include<iostream>
using namespace std;

int main(){
 int arr[6] = {11,21,13};
 cout<<(arr+1) <<endl;

 return 0;   

 ///sahi jawab
}