#include<iostream>
using namespace std;

int main(){
 int arr[6] = {11,12,31};
 cout<<arr<<" "<<&arr<<endl;

 return 0;   
}