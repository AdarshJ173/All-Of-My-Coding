// https://leetcode.com/problems/reverse-string/submissions/1272475562/

// https://www.naukri.com/code360/problems/check-if-the-string-is-a-palindrome_1062633

// https://leetcode.com/problems/valid-palindrome/description/
// https://leetcode.com/problems/valid-palindrome/submissions/1272610509/

// https://leetcode.com/problems/reverse-words-in-a-string-ii/description/

// https://www.geeksforgeeks.org/problems/maximum-occuring-character-1587115620/1

// https://www.naukri.com/code360/problems/replace-spaces_1172172
// https://www.naukri.com/code360/problems/replace-spaces_1172172?leftPanelTabValue=SUBMISSION

// https://leetcode.com/problems/remove-all-occurrences-of-a-substring/submissions/1272884148/

// https://leetcode.com/problems/permutation-in-string/

// https://leetcode.com/problems/remove-all-adjacent-duplicates-in-string/description/

// https://leetcode.com/problems/string-compression/submissions/1272908765/