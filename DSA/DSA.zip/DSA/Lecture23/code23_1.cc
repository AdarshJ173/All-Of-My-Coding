/// WAVE PRINT

// https://www.naukri.com/code360/problems/print-like-a-wave_893268?leftPanelTabValue=SUBMISSION