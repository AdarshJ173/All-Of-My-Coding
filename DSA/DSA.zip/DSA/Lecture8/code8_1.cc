/// CONTINUE

/*
with continue we used to skip an interation.
the use of continue in case of switch is not valid.(try why not)
*/






















