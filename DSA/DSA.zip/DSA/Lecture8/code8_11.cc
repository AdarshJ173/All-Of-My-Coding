//! Question 1 : A.P (3 * n + 7)

#include<iostream>
using namespace std;

 int AP(int n){

        return (3*n+7);
    }

int main(){
    int n;
    cout<<"Enter n: "; cin>>n;

    cout<<AP(n);

}