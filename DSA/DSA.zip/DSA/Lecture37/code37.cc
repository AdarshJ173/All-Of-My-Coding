/// RECURSION - SUBSET / SUBSEQUENCE OF STRING

// https://leetcode.com/problems/subsets/submissions/1279228596/

// https://www.naukri.com/code360/problems/subsequences-of-string_985087?leftPanelTab=0&leftPanelTabValue=SUBMISSION

// by bits manipulation