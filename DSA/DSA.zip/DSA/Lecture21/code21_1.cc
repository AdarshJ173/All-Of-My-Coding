//! Check if Array Is Sorted and Rotated
// https://leetcode.com/problems/check-if-array-is-sorted-and-rotated/description/
// https://leetcode.com/problems/check-if-array-is-sorted-and-rotated/submissions/1272392135/