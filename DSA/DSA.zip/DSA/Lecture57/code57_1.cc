// https://www.geeksforgeeks.org/problems/max-rectangle/1 

