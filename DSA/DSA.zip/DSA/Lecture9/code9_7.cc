/*

swap alternate

find unique

find duplicate

array intersection

array union

pair sum

triplet sum

sort 0's and 1's

*/