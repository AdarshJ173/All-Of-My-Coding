#include<iostream>
using namespace std;

void printArray(int arr[],int size){
    cout<<"Printing the array"<<endl;
    for (int i = 0; i<size; i++)
    {
        cout<<"printing done"<<endl;
    }
    
}

int main(){
    char ch[5] = {'a','b','c','r','p'};
    cout<<"Printing the array"<<endl;
    for (int i = 0; i<5; i++)
    {
        cout<<ch[i]<<" ";
    }
    cout<<"printing done"<<endl;


    double firstdbl[5];
    float firstflt[6];
    bool firstbool[9];


}