    // // constructor
    // Hero(){
    //     cout<<"constructor called"<<endl;
    //     name = new char[100];
    // }