/// PERMUTATION - RECURSION

// https://leetcode.com/problems/permutations/
// https://leetcode.com/problems/permutations/submissions/1280318805/