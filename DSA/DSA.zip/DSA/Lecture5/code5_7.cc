#include<iostream>
using namespace std;

int main(){

    for ( int i = 0 ; i<5 ; i++)
    {
        cout<<"HI"<<endl;
        cout<<"Hello"<<endl;

        continue;

        cout<<"Reply to karde"<<endl;

    }
    
}