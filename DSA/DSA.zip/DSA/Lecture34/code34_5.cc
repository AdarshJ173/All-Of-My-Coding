// insertion sort - using recursion
