// selection sort -- using recursion
