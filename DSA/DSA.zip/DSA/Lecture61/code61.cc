// https://www.geeksforgeeks.org/problems/queue-reversal/1 

// https://www.geeksforgeeks.org/problems/first-negative-integer-in-every-window-of-size-k3345/1 

// https://www.geeksforgeeks.org/problems/reverse-first-k-elements-of-queue/1 

// https://www.geeksforgeeks.org/problems/first-non-repeating-character-in-a-stream1216/1 

// https://www.geeksforgeeks.org/problems/circular-tour-1587115620/1 

// https://www.geeksforgeeks.org/problems/interleave-the-first-half-of-the-queue-with-second-half/1 

// https://www.geeksforgeeks.org/sum-minimum-maximum-elements-subarrays-size-k/ 