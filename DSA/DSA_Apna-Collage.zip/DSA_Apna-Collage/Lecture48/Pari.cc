#include<bits/stdc++.h>
using namespace std;

// Function to demonstrate the use of pairs in C++
int main(){
    // Declare a pair to hold an integer and a character
    pair<int, char> p;

    // Assign values to the pair
    p.first = 3; // Assigning an integer value to the first element of the pair
    p.second = 'j'; // Assigning a character value to the second element of the pair

    // The program does not output or use the pair further, but it demonstrates the declaration and assignment of values to a pair

    return 0;
}