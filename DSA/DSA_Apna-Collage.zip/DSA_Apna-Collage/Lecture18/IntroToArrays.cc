#include<bits/stdc++.h>
using namespace std;
                   
int main(){

    // Array is a list of variables of similar type 
    // {1,2,3,4}
    // {'c','f','h','i'}
    // {'d',3,'f',4.3} not an array

    /*
    datatype arrayName[size];

    int array[4] = {10,20,30,40};

    int - 4 bytes
    array - 4*4 bytes = 16 bytes

    | 2001 | 2002 | 2003 | 2004 | 2005 | 2006 | 2007 | 2008 | 2009 | 2010 | 2011 | 2012 | 2013 | 2014 | 2015 | 2016 |
    |------|------|------|------|------|------|------|------|------|------|------|------|------|------|------|------|
       10                       20                          30                          40
   (array[0])                   (array[1])                  (array[2])                  (array[3])


    */

   int array[4] = {10,20,30,40};
   cout<<array[3]<<endl;

   

return 0;
}