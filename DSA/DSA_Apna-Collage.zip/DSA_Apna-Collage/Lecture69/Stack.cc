#include<iostream>
using namespace std;
                   
int main(){

    /*
    *Stack :
        Stores a list of items in which an item can be added to or removed from the list only at one end.

    *LIFO : Last In First Out

    push(x) - Insert element x in the stack ( at top )
    pop() - removes the top element from the stack (i.e x)   
    top() - returns and points the topmost element in the stack
    empty() - tells(true/false) if the stack is empty or not
    !all of the above function run in constant time (O1) 
    
    */

}