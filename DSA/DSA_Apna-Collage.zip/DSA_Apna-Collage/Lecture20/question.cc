/*

u have 15 rupees
1 rupee = 1 chocolate
3 wrappers = 1 chocolate

ans = 22 


*/