#include<iostream>
#include<queue>5
using namespace std;
                   
int main(){

    /*

    *Queue:
        -Stores a list of items in which an item can be inserted at one end and removed from the other end only
    ?FIFO - FIRST IN FIRST OUT

    we keep two pointers front and back in a queue

    enqueue(x) - inserts and element(x) at back of the queue
    dequeue() - removes an element from front
    peek() - tell the value of front element
    empty() - 

    */

}