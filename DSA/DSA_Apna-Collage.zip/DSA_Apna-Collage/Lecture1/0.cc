// Your C++ code here
#include<iostream>
using namespace std;

int main(){
    cout<<"Adarsh"<<endl<<"Jagannath";

return 0;    
}