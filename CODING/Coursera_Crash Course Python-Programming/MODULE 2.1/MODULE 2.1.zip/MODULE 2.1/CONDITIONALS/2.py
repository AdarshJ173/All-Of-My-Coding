num = float(input("enter the value: "))

if (num < 0 ):
    print("number is negative")
elif (num == 0 ):
    print("number is zero")
else: 
    print("number is positive")