
#* variables 
#* data types
#* int()
#* str()
#* float()
#* len()
#* type()
#* boolean
#* operators - arithmetic & logical
#* functions
#* return
#* conditionals 


name = "adarsh"
print(len(name))

