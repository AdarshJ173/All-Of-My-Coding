# ZEN OF PYTHON 
import this 
