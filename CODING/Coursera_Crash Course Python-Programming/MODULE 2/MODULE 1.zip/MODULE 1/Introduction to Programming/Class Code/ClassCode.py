# print("adarsh jagnnath")

# print(7)

# aj = "adarsh"
# if aj == "adarsh":
#     print("yes")
# else:
#     print("no")

# print(type("adarsh"))
# print(type("7"))
# print(type(7))

# print(7.1)
# print(type(7.1))

# --------------------------

# i am adarsh a good boy i think 

# this is a number comment
number  = 7
print(number)

name = "AAJ"
print(name)

decimals = 7.1
print(decimals)

print("hi " + name)