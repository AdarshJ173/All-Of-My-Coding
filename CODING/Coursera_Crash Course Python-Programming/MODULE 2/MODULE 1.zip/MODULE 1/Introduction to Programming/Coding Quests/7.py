# What should be the output of the expression below? 
print(2+2/((2+2)+(2**2)))